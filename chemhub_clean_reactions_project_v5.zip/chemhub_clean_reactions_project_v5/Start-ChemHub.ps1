Set-Location $PSScriptRoot
docker compose up -d
Start-Process "http://localhost:3000"
Start-Process "http://localhost:3100/admin"
