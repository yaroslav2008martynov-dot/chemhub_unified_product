﻿param(
  [string]$ProjectRoot = "",
  [string]$AdminToken = ""
)

$ErrorActionPreference = "Stop"

function Find-ProjectRoot {
  param([string]$Start)
  if ($Start -and (Test-Path (Join-Path $Start "apps\api\app\main.py"))) {
    return (Resolve-Path $Start).Path
  }
  $cur = (Get-Location).Path
  for ($i = 0; $i -lt 8; $i++) {
    if (Test-Path (Join-Path $cur "apps\api\app\main.py")) { return $cur }
    $parent = Split-Path $cur -Parent
    if ($parent -eq $cur) { break }
    $cur = $parent
  }
  throw "Project root not found. Pass -ProjectRoot."
}

function Get-Token {
  param([string]$Root, [string]$Given)
  if ($Given) { return $Given }
  if ($env:ADMIN_PASSWORD) { return $env:ADMIN_PASSWORD }
  $envPath = Join-Path $Root ".env"
  if (Test-Path $envPath) {
    $line = Get-Content $envPath | Where-Object { $_ -match '^ADMIN_PASSWORD=' } | Select-Object -First 1
    if ($line) { return (($line -replace '^ADMIN_PASSWORD=', '').Trim().Trim('"').Trim("'")) }
  }
  return "Ch3mHub!Admin#2026"
}

$root = Find-ProjectRoot $ProjectRoot
$token = Get-Token $root $AdminToken
$seedDir = Join-Path $root "data\tretyakov_seed"
$ready = Join-Path $seedDir "tretyakov_ready_seed.jsonl"
$susp = Join-Path $seedDir "tretyakov_suspicious_seed.jsonl"

if (-not (Test-Path $ready)) { throw "Ready seed not found: $ready" }
if (-not (Test-Path $susp)) { throw "Suspicious seed not found: $susp" }

$api = "http://localhost:8000"
$headers = @{ "x-admin-token" = $token; "Content-Type" = "application/json; charset=utf-8" }

function Wait-Api {
  for ($i = 0; $i -lt 60; $i++) {
    try {
      Invoke-RestMethod -Uri "$api/health" -Method GET -TimeoutSec 2 | Out-Null
      return
    } catch {
      Start-Sleep -Seconds 2
    }
  }
  throw "API is not responding at $api/health"
}

function Read-JsonlBatches {
  param([string]$Path, [int]$Size = 100)
  $batch = New-Object System.Collections.Generic.List[object]
  Get-Content $Path -Encoding UTF8 | ForEach-Object {
    if ($_.Trim()) { $batch.Add(($_ | ConvertFrom-Json)) }
    if ($batch.Count -ge $Size) {
      ,@($batch.ToArray())
      $batch.Clear()
    }
  }
  if ($batch.Count -gt 0) { ,@($batch.ToArray()) }
}

Wait-Api

$readyCreated = 0
$readyUpdated = 0
$readySkipped = 0
$pendingAdded = 0
$pendingSkipped = 0

foreach ($batch in Read-JsonlBatches $ready 100) {
  $body = @{ items = $batch } | ConvertTo-Json -Depth 20
  $bytes = [System.Text.Encoding]::UTF8.GetBytes($body)
  $res = Invoke-RestMethod -Uri "$api/admin/tretyakov/import-ready/bulk" -Method POST -Headers $headers -Body $bytes
  $readyCreated += [int]$res.created
  $readyUpdated += [int]$res.updated
  $readySkipped += [int]$res.skipped_duplicate_better
  Write-Host "[READY] created=$readyCreated updated=$readyUpdated skipped=$readySkipped"
}

foreach ($batch in Read-JsonlBatches $susp 100) {
  $body = @{ items = $batch } | ConvertTo-Json -Depth 20
  $bytes = [System.Text.Encoding]::UTF8.GetBytes($body)
  $res = Invoke-RestMethod -Uri "$api/admin/tretyakov/pending/bulk" -Method POST -Headers $headers -Body $bytes
  $pendingAdded += [int]$res.added
  $pendingSkipped += [int]$res.skipped_duplicate
  Write-Host "[PENDING] added=$pendingAdded skipped=$pendingSkipped"
}

Write-Host "[DONE] Ready imported: created=$readyCreated updated=$readyUpdated skipped=$readySkipped"
Write-Host "[DONE] Suspicious pending: added=$pendingAdded skipped=$pendingSkipped"
Write-Host "[REVIEW] $api/admin/tretyakov-review?token=$token"
