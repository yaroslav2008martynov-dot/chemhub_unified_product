﻿param(
  [string]$ProjectRoot = "",
  [string]$AdminToken = ""
)

$ErrorActionPreference = "Stop"

function Find-ProjectRoot {
  param([string]$Start)
  if ($Start -and (Test-Path (Join-Path $Start "apps\api\app\main.py"))) {
    return (Resolve-Path $Start).Path
  }
  $cur = (Get-Location).Path
  for ($i = 0; $i -lt 8; $i++) {
    if (Test-Path (Join-Path $cur "apps\api\app\main.py")) { return $cur }
    $parent = Split-Path $cur -Parent
    if ($parent -eq $cur) { break }
    $cur = $parent
  }
  throw "Project root not found. Run from the project folder or pass -ProjectRoot."
}

$root = Find-ProjectRoot $ProjectRoot
$patchRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$backup = Join-Path $root "backup_before_v10_28_tretyakov_final_import_$stamp"

New-Item -ItemType Directory -Force -Path $backup | Out-Null
Write-Host "[ChemHub v10.28] Project root: $root"
Write-Host "[ChemHub v10.28] Patch root: $patchRoot"

$main = Join-Path $root "apps\api\app\main.py"
if (-not (Test-Path $main)) { throw "apps\api\app\main.py not found" }

Copy-Item $main (Join-Path $backup "main.py") -Force
Write-Host "[OK] Backup created: $backup"

$files = @(
  "apps\api\app\tretyakov_review.py",
  "apps\api\app\tretyakov_import_jsonl.py",
  "apps\api\app\tretyakov_seed_validator.py",
  "scripts\Import-Tretyakov-FinalSeed.ps1",
  "data\tretyakov_seed\tretyakov_ready_seed.jsonl",
  "data\tretyakov_seed\tretyakov_suspicious_seed.jsonl",
  "data\tretyakov_seed\tretyakov_rejected_seed.jsonl",
  "data\tretyakov_seed\tretyakov_duplicates_runtime_policy.jsonl",
  "data\tretyakov_seed\validation_30x_report.json",
  "data\tretyakov_seed\validation_30x_report.md",
  "README_v10_28_TRETYAKOV_FINAL_IMPORT_FIXED.md"
)

foreach ($rel in $files) {
  $srcFile = Join-Path $patchRoot $rel
  $dstFile = Join-Path $root $rel
  if (-not (Test-Path $srcFile)) { throw "Missing patch file: $rel" }
  New-Item -ItemType Directory -Force -Path (Split-Path $dstFile -Parent) | Out-Null
  Copy-Item $srcFile $dstFile -Force
  Write-Host "[OK] Copied $rel"
}

$marker = "ChemHub Tretyakov final import/review routes"
$content = Get-Content $main -Raw -Encoding UTF8

if (($content -notlike "*$marker*") -and ($content -notlike "*register_tretyakov_routes*")) {
  $lines = @(
    "",
    "# $marker",
    "try:",
    "    from app.tretyakov_review import register_tretyakov_routes",
    "    register_tretyakov_routes(app, require_admin, _cleanup_duplicates, export_site_files, _info_score)",
    "except Exception as exc:",
    "    print(f'[ChemHub v10.28] Tretyakov routes were not registered: {exc}')"
  )
  Add-Content -Path $main -Value $lines -Encoding UTF8
  Write-Host "[OK] Patched main.py with Tretyakov routes"
} else {
  Write-Host "[SKIP] main.py already contains Tretyakov routes"
}

Write-Host "[INFO] Restarting API container if Docker is available..."
Push-Location $root
try {
  if (Get-Command docker -ErrorAction SilentlyContinue) {
    docker compose build api
    docker compose up -d api
    Write-Host "[OK] API rebuilt/restarted"
  } else {
    Write-Host "[WARN] Docker not found. API must be running before import."
  }
} finally {
  Pop-Location
}

& (Join-Path $root "scripts\Import-Tretyakov-FinalSeed.ps1") -ProjectRoot $root -AdminToken $AdminToken

Write-Host ""
Write-Host "[DONE] v10.28 installed. Ready seed imported; suspicious seed is on review page."
Write-Host "[REPORT] data\tretyakov_seed\validation_30x_report.md"
