from __future__ import annotations

from datetime import datetime
from html import escape
from typing import Any, Callable

from fastapi import Depends, HTTPException, Query
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from sqlalchemy import Boolean, DateTime, Float, Integer, String, Text
from sqlalchemy.orm import Mapped, Session, mapped_column

from app.config import settings
from app.db import Base, get_db
try:
    from app.db import engine
except Exception:
    engine = None
from app.models import Reaction
from app.extractor import canonical_equation


class TretyakovPendingReaction(Base):
    __tablename__ = "tretyakov_pending_reactions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    reaction_name: Mapped[str] = mapped_column(String(255), default="")
    equation: Mapped[str] = mapped_column(Text)
    canonical_equation: Mapped[str] = mapped_column(Text, default="")
    reactants: Mapped[str] = mapped_column(Text, default="")
    products: Mapped[str] = mapped_column(Text, default="")
    conditions: Mapped[str] = mapped_column(Text, default="")
    catalysts: Mapped[str] = mapped_column(Text, default="")
    solvents: Mapped[str] = mapped_column(Text, default="")
    temperature: Mapped[str] = mapped_column(String(100), default="")
    pressure: Mapped[str] = mapped_column(String(100), default="")
    states: Mapped[str] = mapped_column(Text, default="")
    source_pdf: Mapped[str] = mapped_column(String(500), default="Третьяков")
    source_page: Mapped[int] = mapped_column(Integer, default=0)
    source_excerpt: Mapped[str] = mapped_column(Text, default="")
    review_reason: Mapped[str] = mapped_column(Text, default="")
    confidence_score: Mapped[float] = mapped_column(Float, default=0.5)
    selected: Mapped[bool] = mapped_column(Boolean, default=True)
    status: Mapped[str] = mapped_column(String(50), default="pending")  # pending / approved / rejected
    decision_note: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class TretyakovReactionIn(BaseModel):
    reaction_name: str = ""
    equation: str
    reactants: str = ""
    products: str = ""
    conditions: str = ""
    catalysts: str = ""
    solvents: str = ""
    temperature: str = ""
    pressure: str = ""
    states: str = ""
    source_pdf: str = "Третьяков"
    source_page: int = 0
    source_excerpt: str = ""
    review_reason: str = ""
    confidence_score: float = 0.5


class TretyakovBulkIn(BaseModel):
    items: list[TretyakovReactionIn]


class TretyakovDecisionIn(BaseModel):
    edited: TretyakovReactionIn | None = None
    note: str = ""


def _as_dict(row: Any) -> dict[str, Any]:
    return {
        "id": row.id,
        "reaction_name": row.reaction_name or "",
        "equation": row.equation or "",
        "canonical_equation": row.canonical_equation or "",
        "reactants": row.reactants or "",
        "products": row.products or "",
        "conditions": row.conditions or "",
        "catalysts": row.catalysts or "",
        "solvents": row.solvents or "",
        "temperature": row.temperature or "",
        "pressure": row.pressure or "",
        "states": row.states or "",
        "source_pdf": row.source_pdf or "Третьяков",
        "source_page": row.source_page or 0,
        "source_excerpt": row.source_excerpt or "",
        "review_reason": row.review_reason or "",
        "confidence_score": row.confidence_score or 0.5,
        "status": row.status or "pending",
        "decision_note": row.decision_note or "",
    }


def _info_score_data(data: dict[str, Any]) -> int:
    fields = [
        "reaction_name",
        "equation",
        "reactants",
        "products",
        "conditions",
        "catalysts",
        "solvents",
        "temperature",
        "pressure",
        "states",
        "source_pdf",
        "source_excerpt",
    ]
    return sum(len(str(data.get(f, "") or "")) for f in fields)


def _split_equation(eq: str) -> tuple[str, str]:
    text = (eq or "").replace("->", "→").replace("=>", "→").replace("=", "→")
    if "⇌" in text:
        left, right = text.split("⇌", 1)
    elif "→" in text:
        left, right = text.split("→", 1)
    else:
        return "", ""
    return left.strip(), right.strip()


def _normalize_incoming(item: TretyakovReactionIn | dict[str, Any]) -> dict[str, Any]:
    data = item.model_dump() if hasattr(item, "model_dump") else dict(item)
    data["equation"] = (data.get("equation") or "").replace("->", "→").replace("=>", "→").replace("=", "→").strip()
    data["canonical_equation"] = canonical_equation(data["equation"])
    if not data.get("reactants") or not data.get("products"):
        left, right = _split_equation(data["equation"])
        data["reactants"] = data.get("reactants") or left
        data["products"] = data.get("products") or right
    data["source_pdf"] = data.get("source_pdf") or "Третьяков"
    data["source_page"] = int(data.get("source_page") or 0)
    data["confidence_score"] = float(data.get("confidence_score") or 0.5)
    return data


def _upsert_reaction_from_data(
    data: dict[str, Any],
    db: Session,
    info_score: Callable[[Any], int] | None = None,
) -> tuple[Reaction, bool, bool]:
    data = _normalize_incoming(data)
    if not data.get("equation") or not data.get("canonical_equation"):
        raise HTTPException(status_code=400, detail="equation is required")

    existing = (
        db.query(Reaction)
        .filter(Reaction.canonical_equation == data["canonical_equation"])
        .order_by(Reaction.id.asc())
        .first()
    )

    candidate_score = _info_score_data(data)
    if existing:
        existing_score = info_score(existing) if info_score else _info_score_data(existing.__dict__)
        if existing_score >= candidate_score:
            return existing, False, True
        reaction = existing
        created = False
    else:
        reaction = Reaction()
        created = True
        try:
            reaction.created_at = datetime.utcnow()
        except Exception:
            pass

    for field in [
        "reaction_name",
        "equation",
        "canonical_equation",
        "reactants",
        "products",
        "conditions",
        "catalysts",
        "solvents",
        "temperature",
        "pressure",
        "states",
        "source_pdf",
        "source_page",
        "confidence_score",
    ]:
        if field in data:
            setattr(reaction, field, data[field])

    reaction.validation_status = "approved_from_tretyakov"
    reaction.internet_status = "not_checked"
    reaction.internet_note = ""
    reaction.approved = True
    reaction.hidden = False
    reaction.origin = "tretyakov"
    reaction.updated_at = datetime.utcnow()
    db.add(reaction)
    return reaction, created, False


def _review_html(token: str) -> str:
    safe_token = escape(token, quote=True)
    return f"""<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Проверка сомнительных реакций Третьякова</title>
  <style>
    :root {{ font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; color: #111827; background: #f3f4f6; }}
    body {{ margin: 0; padding: 24px; }}
    main {{ max-width: 1100px; margin: 0 auto; }}
    h1 {{ margin: 0 0 8px; }}
    .muted {{ color: #6b7280; }}
    .panel, .card {{ background: white; border: 1px solid #e5e7eb; border-radius: 18px; box-shadow: 0 10px 24px rgba(0,0,0,.05); }}
    .panel {{ padding: 18px; margin-bottom: 16px; display: flex; gap: 12px; align-items: center; justify-content: space-between; flex-wrap: wrap; }}
    .card {{ padding: 18px; margin: 14px 0; }}
    textarea, input {{ width: 100%; box-sizing: border-box; border: 1px solid #d1d5db; border-radius: 12px; padding: 10px 12px; font-size: 15px; margin: 6px 0 10px; }}
    textarea {{ min-height: 74px; font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; }}
    label {{ display: block; font-weight: 650; margin-top: 6px; }}
    .grid {{ display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; }}
    .eq {{ font-size: 20px; font-weight: 750; padding: 12px; border-radius: 12px; background: #f9fafb; overflow-wrap: anywhere; }}
    .excerpt {{ white-space: pre-wrap; font-size: 13px; background: #fffbeb; border: 1px solid #fde68a; border-radius: 12px; padding: 10px; }}
    .reason {{ color: #92400e; font-weight: 650; }}
    button {{ border: 0; border-radius: 12px; padding: 10px 14px; font-weight: 750; cursor: pointer; }}
    .ok {{ background: #16a34a; color: white; }}
    .bad {{ background: #dc2626; color: white; }}
    .ghost {{ background: #e5e7eb; color: #111827; }}
    .actions {{ display: flex; gap: 10px; margin-top: 10px; flex-wrap: wrap; }}
    .empty {{ text-align: center; padding: 40px; }}
    @media (max-width: 800px) {{ .grid {{ grid-template-columns: 1fr; }} }}
  </style>
</head>
<body>
<main>
  <div class="panel">
    <div>
      <h1>Сомнительные реакции из Третьякова</h1>
      <div class="muted">Проверяй карточку, при необходимости исправляй поля, затем нажимай «Добавить» или «Не добавлять». После решения карточка исчезает.</div>
    </div>
    <div><b id="counter">...</b></div>
  </div>
  <section id="list"></section>
</main>
<script>
const TOKEN = "{safe_token}";
const headers = {{ 'Content-Type': 'application/json', 'x-admin-token': TOKEN }};
let items = [];
function esc(s) {{ return String(s || '').replace(/[&<>\"]/g, c => ({{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}}[c])); }}
async function load() {{
  const res = await fetch('/admin/tretyakov/pending', {{ headers }});
  if (!res.ok) {{ document.getElementById('list').innerHTML = '<div class="card empty">Не удалось загрузить список. Проверь пароль/token.</div>'; return; }}
  const data = await res.json();
  items = data.items || [];
  render(data.total || items.length);
}}
function render(total) {{
  document.getElementById('counter').textContent = `Осталось: ${{total}}`;
  const root = document.getElementById('list');
  if (!items.length) {{
    root.innerHTML = '<div class="card empty"><h2>Все сомнительные реакции проверены</h2><p class="muted">Временная страница больше не нужна: при следующем открытии без force=1 она вернёт 404.</p></div>';
    return;
  }}
  root.innerHTML = items.map((r, idx) => `
    <article class="card" data-id="${{r.id}}">
      <div class="muted">#${{r.id}} · ${{esc(r.source_pdf)}}${{r.source_page ? ', стр. ' + r.source_page : ''}}</div>
      <div class="eq">${{esc(r.equation)}}</div>
      <p class="reason">Причина проверки: ${{esc(r.review_reason || 'нужна ручная проверка')}}</p>
      <label>Уравнение</label><textarea data-f="equation">${{esc(r.equation)}}</textarea>
      <div class="grid">
        <div><label>Название</label><input data-f="reaction_name" value="${{esc(r.reaction_name)}}" /></div>
        <div><label>Условия на русском</label><input data-f="conditions" value="${{esc(r.conditions)}}" /></div>
        <div><label>Катализатор</label><input data-f="catalysts" value="${{esc(r.catalysts)}}" /></div>
        <div><label>Температура</label><input data-f="temperature" value="${{esc(r.temperature)}}" /></div>
        <div><label>Давление</label><input data-f="pressure" value="${{esc(r.pressure)}}" /></div>
        <div><label>Растворитель/среда</label><input data-f="solvents" value="${{esc(r.solvents)}}" /></div>
      </div>
      <label>Реагенты</label><input data-f="reactants" value="${{esc(r.reactants)}}" />
      <label>Продукты</label><input data-f="products" value="${{esc(r.products)}}" />
      <label>Фрагмент источника</label><div class="excerpt">${{esc(r.source_excerpt)}}</div>
      <div class="actions">
        <button class="ok" onclick="approve(${{idx}})">Добавить на сайт</button>
        <button class="bad" onclick="rejectItem(${{idx}})">Не добавлять</button>
        <button class="ghost" onclick="load()">Обновить</button>
      </div>
    </article>`).join('');
}}
function collect(card, original) {{
  const data = {{ ...original }};
  card.querySelectorAll('[data-f]').forEach(el => data[el.dataset.f] = el.value);
  data.source_page = Number(data.source_page || 0);
  data.confidence_score = Number(data.confidence_score || 0.5);
  return data;
}}
async function approve(idx) {{
  const r = items[idx];
  const card = document.querySelector(`[data-id="${{r.id}}"]`);
  const edited = collect(card, r);
  const res = await fetch(`/admin/tretyakov/pending/${{r.id}}/approve`, {{ method: 'POST', headers, body: JSON.stringify({{ edited }}) }});
  if (!res.ok) return alert(await res.text());
  items.splice(idx, 1); render(items.length);
}}
async function rejectItem(idx) {{
  const r = items[idx];
  const note = prompt('Почему не добавляем? Можно оставить пустым.') || '';
  const res = await fetch(`/admin/tretyakov/pending/${{r.id}}/reject`, {{ method: 'POST', headers, body: JSON.stringify({{ note }}) }});
  if (!res.ok) return alert(await res.text());
  items.splice(idx, 1); render(items.length);
}}
load();
</script>
</body>
</html>"""


def register_tretyakov_routes(
    app,
    require_admin,
    cleanup_duplicates: Callable[[Session], None] | None = None,
    export_site_files: Callable[[Session], Any] | None = None,
    info_score: Callable[[Any], int] | None = None,
) -> None:
    """Register temporary Tretyakov import/review endpoints without touching the React admin app."""
    if engine is not None:
        try:
            Base.metadata.create_all(bind=engine)
        except Exception as exc:
            print(f"[ChemHub v10.27] Could not create Tretyakov review table: {exc}")


    @app.get("/admin/tretyakov/pending", dependencies=[Depends(require_admin)])
    def tretyakov_pending(limit: int = 50, db: Session = Depends(get_db)):
        q = db.query(TretyakovPendingReaction).filter(TretyakovPendingReaction.status == "pending")
        total = q.count()
        rows = q.order_by(TretyakovPendingReaction.id.asc()).limit(max(1, min(limit, 200))).all()
        return {"total": total, "items": [_as_dict(r) for r in rows]}

    @app.post("/admin/tretyakov/pending/bulk", dependencies=[Depends(require_admin)])
    def tretyakov_pending_bulk(payload: TretyakovBulkIn, db: Session = Depends(get_db)):
        added = 0
        skipped_duplicate = 0
        for item in payload.items:
            data = _normalize_incoming(item)
            if not data.get("equation") or not data.get("canonical_equation"):
                continue
            existing_live = db.query(Reaction).filter(Reaction.canonical_equation == data["canonical_equation"]).first()
            existing_pending = (
                db.query(TretyakovPendingReaction)
                .filter(TretyakovPendingReaction.canonical_equation == data["canonical_equation"])
                .first()
            )
            if existing_live or existing_pending:
                skipped_duplicate += 1
                continue
            row = TretyakovPendingReaction(**data, status="pending", selected=True)
            db.add(row)
            added += 1
        db.commit()
        return {"added": added, "skipped_duplicate": skipped_duplicate}

    @app.post("/admin/tretyakov/import-ready/bulk", dependencies=[Depends(require_admin)])
    def tretyakov_import_ready_bulk(payload: TretyakovBulkIn, db: Session = Depends(get_db)):
        created = 0
        updated = 0
        skipped_duplicate_better = 0
        for item in payload.items:
            data = _normalize_incoming(item)
            _, was_created, skipped = _upsert_reaction_from_data(data, db, info_score=info_score)
            if skipped:
                skipped_duplicate_better += 1
            elif was_created:
                created += 1
            else:
                updated += 1
        db.commit()
        if cleanup_duplicates:
            cleanup_duplicates(db)
        if export_site_files:
            export_site_files(db)
        return {"created": created, "updated": updated, "skipped_duplicate_better": skipped_duplicate_better}

    @app.post("/admin/tretyakov/pending/{pending_id}/approve", dependencies=[Depends(require_admin)])
    def tretyakov_approve(pending_id: int, payload: TretyakovDecisionIn, db: Session = Depends(get_db)):
        row = db.get(TretyakovPendingReaction, pending_id)
        if not row or row.status != "pending":
            raise HTTPException(status_code=404, detail="Pending reaction not found")
        data = _as_dict(row)
        if payload.edited:
            data.update(payload.edited.model_dump())
        _upsert_reaction_from_data(data, db, info_score=info_score)
        row.status = "approved"
        row.decision_note = payload.note or "approved"
        row.updated_at = datetime.utcnow()
        db.commit()
        if cleanup_duplicates:
            cleanup_duplicates(db)
        if export_site_files:
            export_site_files(db)
        return {"approved": True, "pending_id": pending_id}

    @app.post("/admin/tretyakov/pending/{pending_id}/reject", dependencies=[Depends(require_admin)])
    def tretyakov_reject(pending_id: int, payload: TretyakovDecisionIn, db: Session = Depends(get_db)):
        row = db.get(TretyakovPendingReaction, pending_id)
        if not row or row.status != "pending":
            raise HTTPException(status_code=404, detail="Pending reaction not found")
        row.status = "rejected"
        row.decision_note = payload.note or "rejected"
        row.updated_at = datetime.utcnow()
        db.commit()
        return {"rejected": True, "pending_id": pending_id}

    @app.get("/admin/tretyakov-review", response_class=HTMLResponse)
    def tretyakov_review_page(
        token: str = Query(""),
        force: bool = Query(False),
        db: Session = Depends(get_db),
    ):
        if token != settings.ADMIN_PASSWORD:
            raise HTTPException(status_code=401, detail="Admin token is required")
        pending_count = db.query(TretyakovPendingReaction).filter(TretyakovPendingReaction.status == "pending").count()
        if pending_count == 0 and not force:
            raise HTTPException(status_code=404, detail="Сомнительных реакций нет; временная страница скрыта")
        return HTMLResponse(_review_html(token))

    @app.get("/admin/tretyakov/status", dependencies=[Depends(require_admin)])
    def tretyakov_status(db: Session = Depends(get_db)):
        statuses = {}
        for status in ["pending", "approved", "rejected"]:
            statuses[status] = db.query(TretyakovPendingReaction).filter(TretyakovPendingReaction.status == status).count()
        live = db.query(Reaction).filter(Reaction.origin == "tretyakov").count()
        statuses["live_tretyakov_reactions"] = live
        return statuses
