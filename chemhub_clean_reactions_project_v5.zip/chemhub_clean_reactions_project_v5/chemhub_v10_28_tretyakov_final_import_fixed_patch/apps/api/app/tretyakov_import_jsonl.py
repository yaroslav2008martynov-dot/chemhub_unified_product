from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path


def read_jsonl(path: Path) -> list[dict]:
    if not path.exists():
        return []
    rows = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def post_json(api: str, token: str, path: str, payload: dict) -> dict:
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        api.rstrip("/") + path,
        data=data,
        headers={"Content-Type": "application/json", "x-admin-token": token},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            body = resp.read().decode("utf-8", errors="replace")
            return json.loads(body) if body else {}
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {exc.code} for {path}: {body}") from exc


def chunks(rows: list[dict], size: int = 200):
    for i in range(0, len(rows), size):
        yield rows[i:i + size]


def main() -> int:
    p = argparse.ArgumentParser(description="Import Tretyakov JSONL reactions into ChemHub API.")
    p.add_argument("--api", default="http://localhost:8000")
    p.add_argument("--token", default=os.getenv("ADMIN_PASSWORD", ""))
    p.add_argument("--ready", required=True)
    p.add_argument("--suspicious", required=True)
    args = p.parse_args()

    if not args.token:
        print("ADMIN token is required", file=sys.stderr)
        return 2

    ready = read_jsonl(Path(args.ready))
    suspicious = read_jsonl(Path(args.suspicious))
    summary = {"ready_input": len(ready), "suspicious_input": len(suspicious), "ready_import": [], "pending_import": []}

    for batch in chunks(ready):
        summary["ready_import"].append(post_json(args.api, args.token, "/admin/tretyakov/import-ready/bulk", {"items": batch}))
    for batch in chunks(suspicious):
        summary["pending_import"].append(post_json(args.api, args.token, "/admin/tretyakov/pending/bulk", {"items": batch}))

    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
