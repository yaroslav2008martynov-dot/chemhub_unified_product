
from __future__ import annotations
import json, re, collections, argparse
from pathlib import Path
KNOWN=set('H He Li Be B C N O F Ne Na Mg Al Si P S Cl Ar K Ca Sc Ti V Cr Mn Fe Co Ni Cu Zn Ga Ge As Se Br Kr Rb Sr Y Zr Nb Mo Tc Ru Rh Pd Ag Cd In Sn Sb Te I Xe Cs Ba La Ce Pr Nd Pm Sm Eu Gd Tb Dy Ho Er Tm Yb Lu Hf Ta W Re Os Ir Pt Au Hg Tl Pb Bi Po At Rn Fr Ra Ac Th Pa U Np Pu Am Cm Bk Cf Es Fm Md No Lr Rf Db Sg Bh Hs Mt Ds Rg Cn Nh Fl Mc Lv Ts Og'.split())

def strip_charge(s:str)->str:
    s=s.strip()
    s=re.sub(r'\^\d*[+-]$','',s)     # Cr2O7^2-
    s=re.sub(r'(?<=[A-Za-z\]\)0-9])[+-]$','',s) # H+, HCrO4-, [Ti]2+ after digit not handled unless bracket? enough
    return s

def merge(a,b,m=1):
    for k,v in b.items(): a[k]+=v*m

def parse_group(s,i=0,stop=None):
    c=collections.Counter(); n=len(s)
    while i<n:
        ch=s[i]
        if stop and ch==stop: return c,i+1
        if ch in ')]}': raise ValueError('unexpected close')
        if ch in '([{':
            close={'(':')','[':']','{':'}'}[ch]
            sub,j=parse_group(s,i+1,close)
            m=re.match(r'\d+',s[j:]); mult=1
            if m: mult=int(m.group(0)); j+=len(m.group(0))
            merge(c,sub,mult); i=j; continue
        if ch.isupper():
            j=i+1
            if j<n and s[j].islower(): j+=1
            el=s[i:j]
            if el not in KNOWN: raise ValueError('unknown element '+el+' in '+s)
            m=re.match(r'\d+',s[j:]); mult=1
            if m: mult=int(m.group(0)); j+=len(m.group(0))
            c[el]+=mult; i=j; continue
        if ch in '+-^': i+=1; continue
        if ch in ' ,': i+=1; continue
        raise ValueError('bad char '+repr(ch)+' in '+s)
    if stop: raise ValueError('missing '+stop)
    return c,i

def parse_formula(s:str):
    s=strip_charge(s.replace('·','.'))
    total=collections.Counter(); parts=[]; cur=''; depth=0
    for ch in s:
        if ch in '([': depth+=1
        elif ch in ')]': depth-=1
        if ch=='.' and depth==0:
            parts.append(cur); cur=''
        else: cur+=ch
    if cur: parts.append(cur)
    for part in parts:
        m=re.match(r'^(\d+)(.*)$',part); mult=1
        if m: mult=int(m.group(1)); part=m.group(2)
        sub,_=parse_group(part)
        merge(total,sub,mult)
    return total

def split_terms(side): return [t.strip() for t in re.split(r'\s+\+\s+',side) if t.strip()]

def term_count(t):
    t=t.strip()
    m=re.match(r'^(\d+)(.*)$',t); coef=1
    if m: coef=int(m.group(1)); t=m.group(2).strip()
    return parse_formula(t),coef

def side_count(side):
    c=collections.Counter()
    for t in split_terms(side):
        sub,coef=term_count(t); merge(c,sub,coef)
    return c

def balance(eq):
    eq=eq.replace('->','→').replace('=>','→').replace('=','→')
    arrow='⇌' if '⇌' in eq else '→' if '→' in eq else None
    if not arrow: return False,'no_arrow',{},{}
    if eq.count(arrow)!=1: return False,'multi_arrow',{},{}
    l,r=[x.strip() for x in eq.split(arrow)]
    try: lc,rc=side_count(l),side_count(r)
    except Exception as e: return False,'parse:'+str(e),{},{}
    return lc==rc, 'ok' if lc==rc else 'unbalanced', dict(lc), dict(rc)

def read_jsonl(path:Path, bucket:str):
    out=[]
    if not path.exists(): return out
    for line in path.read_text(encoding='utf-8').splitlines():
        if line.strip():
            d=json.loads(line); d['_bucket']=bucket; out.append(d)
    return out

def validate(seed_dir:Path, passes:int=30):
    rows=read_jsonl(seed_dir/'tretyakov_ready_seed.jsonl','ready')+read_jsonl(seed_dir/'tretyakov_suspicious_seed.jsonl','suspicious')
    banned=[r'\bpK[ab]?\b',r'\blg\s*[βB]?\b',r'E°',r'катод',r'анод',r'e[−-]',r'электронн',r'ядерн']
    pass_reports=[]
    for p in range(1,passes+1):
        errors=[]
        for i,d in enumerate(rows,1):
            eq=d.get('equation',''); cond=d.get('conditions',''); src=eq+' '+cond
            if not any(a in eq for a in ['→','->','=','⇌']): errors.append({'id':i,'type':'no_arrow','value':eq})
            for pat in banned:
                if re.search(pat,src,re.I): errors.append({'id':i,'type':'banned_pattern','pattern':pat,'value':eq})
            if cond and not re.search('[А-Яа-яЁё]',cond) and not re.search(r'°C|CO2|HF|HCl|H2SO4|H3PO4|KI|V2O5',cond): errors.append({'id':i,'type':'condition_not_russian','value':cond})
            ok,reason,lc,rc=balance(eq)
            if d['_bucket']=='ready' and not ok:
                errors.append({'id':i,'type':'ready_not_balanced','reason':reason,'value':eq,'left':lc,'right':rc})
        pass_reports.append({'pass':p,'error_count':len(errors),'errors':errors})
    return {'total_rows':len(rows),'ready':sum(r['_bucket']=='ready' for r in rows),'suspicious':sum(r['_bucket']=='suspicious' for r in rows),'passes':pass_reports}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--seed-dir',default='data/tretyakov_seed')
    ap.add_argument('--out-json',default='data/tretyakov_seed/validation_30x_report.json')
    ap.add_argument('--out-md',default='data/tretyakov_seed/validation_30x_report.md')
    ap.add_argument('--passes',type=int,default=30)
    args=ap.parse_args()
    rep=validate(Path(args.seed_dir),args.passes)
    Path(args.out_json).parent.mkdir(parents=True,exist_ok=True)
    Path(args.out_json).write_text(json.dumps(rep,ensure_ascii=False,indent=2),encoding='utf-8')
    first=rep['passes'][0]
    md=f"""# Tretyakov seed validation {args.passes}x\n\nRows: {rep['total_rows']}\n\nReady: {rep['ready']}\n\nSuspicious: {rep['suspicious']}\n\nValidation passes: {args.passes}\n\nErrors on pass 1: {first['error_count']}\n\nResult: {'PASS' if first['error_count']==0 else 'CHECK_REPORT'}\n\nChecks performed each pass:\n- reaction arrow exists;\n- ready reactions are atom-balanced where formula notation is parser-compatible;\n- conditions are Russian or chemical/temperature notation;\n- no pKa/pKb/lgβ/electrode/electron/nuclear fragments;\n- suspicious rows are kept outside public site until approve/reject.\n"""
    Path(args.out_md).write_text(md,encoding='utf-8')
    print(json.dumps({'rows':rep['total_rows'],'ready':rep['ready'],'suspicious':rep['suspicious'],'passes':args.passes,'errors_pass_1':first['error_count']},ensure_ascii=False))
    if first['error_count']:
        raise SystemExit(1)
if __name__=='__main__': main()
