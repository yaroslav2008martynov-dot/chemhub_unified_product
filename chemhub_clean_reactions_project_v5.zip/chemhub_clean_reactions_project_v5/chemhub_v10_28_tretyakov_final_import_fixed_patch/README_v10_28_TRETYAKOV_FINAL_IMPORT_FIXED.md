# ChemHub v10.28 Tretyakov Final Import Fixed

This is the same seed import as v10.27, but with a safer PowerShell installer.

Why v10.28:
- Uses the real project folder you showed: C:\chemhub_clean_reactions_project_v5
- ASCII-safe PowerShell messages.
- No embedded here-string Python block in the installer.
- Keeps the same seed counts:
  - 283 ready reactions imported directly
  - 1451 suspicious candidates added to review page
  - 444 rejected rows in report
  - 30 validation passes, 0 ready-seed errors

Run from PowerShell:

```powershell
$ProjectRoot = "C:\chemhub_clean_reactions_project_v5"
$PatchZip = "$env:USERPROFILE\Downloads\chemhub_v10_28_tretyakov_final_import_fixed_patch.zip"

cd $ProjectRoot
Remove-Item ".\chemhub_v10_28_tretyakov_final_import_fixed_patch" -Recurse -Force -ErrorAction SilentlyContinue
Expand-Archive -Path $PatchZip -DestinationPath $ProjectRoot -Force

powershell -ExecutionPolicy Bypass -File ".\chemhub_v10_28_tretyakov_final_import_fixed_patch\Apply-ChemHub-v10.28-TretyakovFinalImportFixed.ps1" -ProjectRoot $ProjectRoot
```
