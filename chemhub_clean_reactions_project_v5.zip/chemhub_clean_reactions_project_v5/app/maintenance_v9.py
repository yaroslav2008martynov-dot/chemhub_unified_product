"""ChemHub Clean v9 maintenance.

Cleans an existing SQLite database without rebuilding the whole project:
- preserves cumulative v8 fixes (Ac != acetate, admin editing API, ion-equation cleanup),
- normalizes duplicate/noisy reaction conditions,
- removes short condition clauses that are contained inside a fuller clause:
  "без катализатора; горение без катализатора" -> "горение без катализатора",
- merges duplicate normalized reactions after edits/imports.
"""
import json
import time
from server import (
    connect, clean_eq, split_equation, normalized_key, extract_elements,
    normalize_conditions, merge_conditions, is_ion_equation
)


def run():
    con = connect()
    cur = con.cursor()
    rows = cur.execute('SELECT * FROM reactions ORDER BY id').fetchall()
    removed_ion = 0
    cleaned_conditions = 0
    reindexed = 0
    merged_dupes = 0
    seen = {}

    for row in rows:
        d = dict(row)
        rid = d['id']
        eq = clean_eq(d.get('equation') or '')
        if is_ion_equation(eq):
            cur.execute('DELETE FROM reactions WHERE id=?', (rid,))
            removed_ion += 1
            continue
        left, right, _ = split_equation(eq)
        norm = normalized_key(eq)
        cond = normalize_conditions(d.get('conditions') or '')
        elements = extract_elements(eq)

        if norm in seen:
            primary_id = seen[norm]
            old = cur.execute('SELECT conditions, description, source, origin FROM reactions WHERE id=?', (primary_id,)).fetchone()
            if old:
                new_cond = merge_conditions(old['conditions'] or '', cond)
                desc = old['description'] or d.get('description') or ''
                source = old['source'] or ''
                if d.get('source') and d['source'] not in source:
                    source = (source + '; ' + d['source']).strip('; ')
                origin = old['origin'] or ''
                if d.get('origin') and d['origin'] not in origin:
                    origin = (origin + '; ' + d['origin']).strip('; ')
                cur.execute('UPDATE reactions SET conditions=?, description=?, source=?, origin=?, updated_at=? WHERE id=?',
                            (new_cond, desc, source, origin, time.time(), primary_id))
            cur.execute('DELETE FROM reactions WHERE id=?', (rid,))
            merged_dupes += 1
            continue
        seen[norm] = rid

        if cond != (d.get('conditions') or ''):
            cleaned_conditions += 1
        reindexed += 1
        cur.execute('''UPDATE reactions
                       SET equation=?, reactants=?, products=?, conditions=?, elements_json=?, normalized_key=?, updated_at=?
                       WHERE id=?''',
                    (eq, d.get('reactants') or left, d.get('products') or right,
                     cond, json.dumps(elements, ensure_ascii=False), norm, time.time(), rid))

    con.commit()
    total = cur.execute('SELECT COUNT(*) FROM reactions').fetchone()[0]
    con.close()
    result = {
        'ok': True,
        'total_after': total,
        'removed_ion_equations': removed_ion,
        'cleaned_conditions': cleaned_conditions,
        'reindexed_reactions': reindexed,
        'merged_duplicates': merged_dupes,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return result


if __name__ == '__main__':
    run()
