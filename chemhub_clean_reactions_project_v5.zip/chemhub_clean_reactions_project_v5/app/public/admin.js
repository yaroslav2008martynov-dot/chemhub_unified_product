const $ = s => document.querySelector(s);
let pass = localStorage.getItem('chemhub_admin_password') || '';
let adminCache = new Map();
let editingId = null;
let currentEditingRow = null;

function headers() {
  return { 'Content-Type': 'application/json', 'X-Admin-Password': pass };
}

function esc(s) {
  return (s || '').replace(/[&<>"]/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]));
}

function fmtEq(s) {
  return esc(s || '')
    .replace(/-&gt;/g, '→')
    .replace(/↛/g, '↛')
    .replace(/(?<=[A-Za-z\)\]])(\d+)(?![+\-])/g, '<sub>$1</sub>');
}

function setStatus(text, type = '') {
  const el = $('#formMsg');
  if (!el) return;
  el.textContent = text || '';
  el.className = type ? `muted ${type}` : 'muted';
}

function setEditingMode(row) {
  editingId = row ? row.id : null;
  currentEditingRow = row || null;

  $('#eq').value = row?.equation || '';
  $('#cond').value = row?.conditions || '';
  $('#src').value = row?.source || 'manual';
  $('#desc').value = row?.description || '';
  if ($('#origin')) $('#origin').value = row?.origin || 'manual';
  if ($('#sourcePage')) $('#sourcePage').value = row?.source_page ?? '';
  if ($('#hidden')) $('#hidden').checked = !!row?.hidden;
  if ($('#approved')) $('#approved').checked = row ? !!row.approved : true;

  $('#saveBtn').textContent = editingId ? `Сохранить изменения #${editingId}` : 'Добавить реакцию';
  $('#formTitle').textContent = editingId ? `Редактирование реакции #${editingId}` : 'Добавить реакцию';
  $('#cancelEditBtn').classList.toggle('hidden', !editingId);
  setStatus(editingId ? 'Открыта существующая реакция. После сохранения изменения попадут в базу.' : '', editingId ? 'ok' : '');

  document.querySelectorAll('.admin-row').forEach(x => x.classList.toggle('selected', Number(x.dataset.id) === editingId));
  $('#eq').focus();
}

function itemFromForm() {
  return {
    equation: $('#eq').value.trim(),
    conditions: $('#cond').value.trim(),
    source: $('#src').value.trim() || 'manual',
    description: $('#desc').value.trim(),
    origin: ($('#origin')?.value || currentEditingRow?.origin || 'manual').trim() || 'manual',
    source_page: $('#sourcePage')?.value ? Number($('#sourcePage').value) : null,
    approved: $('#approved') ? $('#approved').checked : true,
    hidden: $('#hidden') ? $('#hidden').checked : false
  };
}

async function login() {
  pass = $('#password').value;
  const r = await fetch('/api/admin/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ password: pass })
  });
  const d = await r.json();
  if (d.ok) {
    localStorage.setItem('chemhub_admin_password', pass);
    $('#loginBox').classList.add('hidden');
    $('#adminApp').classList.remove('hidden');
    loadAdmin();
    loadAdSettings();
  } else {
    $('#loginMsg').textContent = 'Неверный пароль';
  }
}

async function loadAdmin() {
  const s = await (await fetch('/api/stats')).json();
  $('#adminStats').textContent = `Всего в базе: ${s.total}; с условиями: ${s.with_conditions}`;
  const q = $('#adminQ').value.trim();
  const data = await (await fetch('/api/reactions?page_size=120' + (q ? '&q=' + encodeURIComponent(q) : ''))).json();
  adminCache = new Map(data.items.map(r => [Number(r.id), r]));

  $('#adminList').innerHTML = data.items.map(r => `
    <div class="admin-row ${editingId === r.id ? 'selected' : ''}" data-id="${r.id}" onclick="editReaction(${r.id})" title="Нажми, чтобы открыть и редактировать">
      <div class="row-main">
        <b>${r.id}. ${fmtEq(r.equation)}</b>
        ${r.conditions ? `<div class="cond">${esc(r.conditions)}</div>` : ''}
        ${r.description ? `<div class="muted row-desc">${esc(r.description)}</div>` : ''}
      </div>
      <div class="actions" onclick="event.stopPropagation()">
        <button onclick="editReaction(${r.id})" class="ghost">Редактировать</button>
        <button onclick="delReaction(${r.id})" class="danger-btn">Удалить</button>
      </div>
    </div>`).join('');

  if (!data.items.length) {
    $('#adminList').innerHTML = '<div class="muted">Ничего не найдено.</div>';
  }
}

function editReaction(id) {
  const row = adminCache.get(Number(id));
  if (!row) return;
  setEditingMode(row);
  document.querySelector('.admin-grid')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function newReaction() {
  setEditingMode(null);
}

async function loadAdSettings() {
  const ad = await (await fetch('/api/ad')).json();
  $('#adEnabled').checked = !!ad.enabled;
  $('#adTitle').value = ad.title || '';
  $('#adText').value = ad.text || '';
  $('#adUrl').value = ad.url || '';
  $('#adButton').value = ad.button || '';
}

async function saveAd() {
  const ad = {
    enabled: $('#adEnabled').checked,
    title: $('#adTitle').value,
    text: $('#adText').value,
    url: $('#adUrl').value,
    button: $('#adButton').value
  };
  const r = await fetch('/api/admin/ad', { method: 'POST', headers: headers(), body: JSON.stringify(ad) });
  const d = await r.json();
  $('#adMsg').textContent = d.ok ? 'Сохранено' : 'Ошибка';
}

async function saveReaction() {
  const item = itemFromForm();
  if (!item.equation) {
    setStatus('Заполни уравнение реакции.', 'error');
    return;
  }
  const url = editingId ? `/api/admin/reactions/${editingId}` : '/api/admin/reactions';
  const method = editingId ? 'PUT' : 'POST';
  const r = await fetch(url, { method, headers: headers(), body: JSON.stringify(item) });
  const d = await r.json();
  if (!r.ok || d.error) {
    setStatus('Ошибка: ' + (d.error || r.statusText), 'error');
    return;
  }
  setStatus(editingId ? 'Изменения сохранены.' : 'Реакция добавлена.', 'ok');
  await loadAdmin();
}

async function importJson() {
  let data;
  try {
    data = JSON.parse($('#importText').value);
  } catch (e) {
    alert('Ошибка JSON: ' + e.message);
    return;
  }
  const r = await fetch('/api/admin/import', { method: 'POST', headers: headers(), body: JSON.stringify(data) });
  alert(JSON.stringify(await r.json(), null, 2));
  loadAdmin();
}

async function reseed() {
  if (!confirm('Удалить текущую базу и восстановить исходную? Все ручные правки будут потеряны.')) return;
  const r = await fetch('/api/admin/reseed', { method: 'POST', headers: headers() });
  alert(JSON.stringify(await r.json(), null, 2));
  newReaction();
  loadAdmin();
}

async function delReaction(id) {
  if (!confirm('Удалить реакцию #' + id + '?')) return;
  const r = await fetch('/api/admin/reactions/' + id, { method: 'DELETE', headers: headers() });
  const d = await r.json();
  if (!r.ok || d.error) {
    alert('Ошибка удаления: ' + (d.error || r.statusText));
    return;
  }
  if (editingId === id) newReaction();
  loadAdmin();
}

$('#loginBtn').onclick = login;
$('#saveBtn').onclick = saveReaction;
$('#cancelEditBtn').onclick = newReaction;
$('#newReactionBtn').onclick = newReaction;
$('#importBtn').onclick = importJson;
$('#reseedBtn').onclick = reseed;
$('#adminSearch').onclick = loadAdmin;
$('#saveAdBtn').onclick = saveAd;
$('#adminQ').addEventListener('keydown', e => { if (e.key === 'Enter') loadAdmin(); });

if (pass) {
  $('#password').value = pass;
  login();
}
