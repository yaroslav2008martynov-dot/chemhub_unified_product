let state={q:'',element:'',page:1,pageSize:30,total:0};
const $=s=>document.querySelector(s);
function esc(s){return (s||'').replace(/[&<>"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m]));}
function fmtFormula(s){
  return esc(s||'')
    .replace(/-&gt;/g,'→')
    .replace(/&lt;-&gt;/g,'⇄')
    .replace(/(?<=[A-Za-z\)\]])(\d+)(?![+\-])/g,'<sub>$1</sub>');
}
async function api(path){const r=await fetch(path);return r.json();}
async function loadAd(){
  const ad=await api('/api/ad');
  const slot=$('#adSlot');
  if(!ad || !ad.enabled || !(ad.title||ad.text)){slot.classList.add('hidden');return;}
  const body=`<div><b>${esc(ad.title||'Реклама')}</b><span>${esc(ad.text||'')}</span></div>`;
  const btn=ad.url?`<a href="${esc(ad.url)}" target="_blank" rel="noopener">${esc(ad.button||'Подробнее')}</a>`:'';
  slot.innerHTML=body+btn;
  slot.classList.remove('hidden');
}
const ELEMENTS=[
  {z:1,s:'H',n:'Водород',b:'s'},{z:2,s:'He',n:'Гелий',b:'p'},
  {z:3,s:'Li',n:'Литий',b:'s'},{z:4,s:'Be',n:'Бериллий',b:'s'},{z:5,s:'B',n:'Бор',b:'p'},{z:6,s:'C',n:'Углерод',b:'p'},{z:7,s:'N',n:'Азот',b:'p'},{z:8,s:'O',n:'Кислород',b:'p'},{z:9,s:'F',n:'Фтор',b:'p'},{z:10,s:'Ne',n:'Неон',b:'p'},
  {z:11,s:'Na',n:'Натрий',b:'s'},{z:12,s:'Mg',n:'Магний',b:'s'},{z:13,s:'Al',n:'Алюминий',b:'p'},{z:14,s:'Si',n:'Кремний',b:'p'},{z:15,s:'P',n:'Фосфор',b:'p'},{z:16,s:'S',n:'Сера',b:'p'},{z:17,s:'Cl',n:'Хлор',b:'p'},{z:18,s:'Ar',n:'Аргон',b:'p'},
  {z:19,s:'K',n:'Калий',b:'s'},{z:20,s:'Ca',n:'Кальций',b:'s'},{z:21,s:'Sc',n:'Скандий',b:'d'},{z:22,s:'Ti',n:'Титан',b:'d'},{z:23,s:'V',n:'Ванадий',b:'d'},{z:24,s:'Cr',n:'Хром',b:'d'},{z:25,s:'Mn',n:'Марганец',b:'d'},{z:26,s:'Fe',n:'Железо',b:'d'},{z:27,s:'Co',n:'Кобальт',b:'d'},{z:28,s:'Ni',n:'Никель',b:'d'},{z:29,s:'Cu',n:'Медь',b:'d'},{z:30,s:'Zn',n:'Цинк',b:'d'},{z:31,s:'Ga',n:'Галлий',b:'p'},{z:32,s:'Ge',n:'Германий',b:'p'},{z:33,s:'As',n:'Мышьяк',b:'p'},{z:34,s:'Se',n:'Селен',b:'p'},{z:35,s:'Br',n:'Бром',b:'p'},{z:36,s:'Kr',n:'Криптон',b:'p'},
  {z:37,s:'Rb',n:'Рубидий',b:'s'},{z:38,s:'Sr',n:'Стронций',b:'s'},{z:39,s:'Y',n:'Иттрий',b:'d'},{z:40,s:'Zr',n:'Цирконий',b:'d'},{z:41,s:'Nb',n:'Ниобий',b:'d'},{z:42,s:'Mo',n:'Молибден',b:'d'},{z:43,s:'Tc',n:'Технеций',b:'d'},{z:44,s:'Ru',n:'Рутений',b:'d'},{z:45,s:'Rh',n:'Родий',b:'d'},{z:46,s:'Pd',n:'Палладий',b:'d'},{z:47,s:'Ag',n:'Серебро',b:'d'},{z:48,s:'Cd',n:'Кадмий',b:'d'},{z:49,s:'In',n:'Индий',b:'p'},{z:50,s:'Sn',n:'Олово',b:'p'},{z:51,s:'Sb',n:'Сурьма',b:'p'},{z:52,s:'Te',n:'Теллур',b:'p'},{z:53,s:'I',n:'Иод',b:'p'},{z:54,s:'Xe',n:'Ксенон',b:'p'},
  {z:55,s:'Cs',n:'Цезий',b:'s'},{z:56,s:'Ba',n:'Барий',b:'s'},{z:57,s:'La',n:'Лантан',b:'f'},{z:58,s:'Ce',n:'Церий',b:'f'},{z:59,s:'Pr',n:'Празеодим',b:'f'},{z:60,s:'Nd',n:'Неодим',b:'f'},{z:61,s:'Pm',n:'Прометий',b:'f'},{z:62,s:'Sm',n:'Самарий',b:'f'},{z:63,s:'Eu',n:'Европий',b:'f'},{z:64,s:'Gd',n:'Гадолиний',b:'f'},{z:65,s:'Tb',n:'Тербий',b:'f'},{z:66,s:'Dy',n:'Диспрозий',b:'f'},{z:67,s:'Ho',n:'Гольмий',b:'f'},{z:68,s:'Er',n:'Эрбий',b:'f'},{z:69,s:'Tm',n:'Тулий',b:'f'},{z:70,s:'Yb',n:'Иттербий',b:'f'},{z:71,s:'Lu',n:'Лютеций',b:'f'},{z:72,s:'Hf',n:'Гафний',b:'d'},{z:73,s:'Ta',n:'Тантал',b:'d'},{z:74,s:'W',n:'Вольфрам',b:'d'},{z:75,s:'Re',n:'Рений',b:'d'},{z:76,s:'Os',n:'Осмий',b:'d'},{z:77,s:'Ir',n:'Иридий',b:'d'},{z:78,s:'Pt',n:'Платина',b:'d'},{z:79,s:'Au',n:'Золото',b:'d'},{z:80,s:'Hg',n:'Ртуть',b:'d'},{z:81,s:'Tl',n:'Таллий',b:'p'},{z:82,s:'Pb',n:'Свинец',b:'p'},{z:83,s:'Bi',n:'Висмут',b:'p'},{z:84,s:'Po',n:'Полоний',b:'p'},{z:85,s:'At',n:'Астат',b:'p'},{z:86,s:'Rn',n:'Радон',b:'p'},
  {z:87,s:'Fr',n:'Франций',b:'s'},{z:88,s:'Ra',n:'Радий',b:'s'},{z:89,s:'Ac',n:'Актиний',b:'f'},{z:90,s:'Th',n:'Торий',b:'f'},{z:91,s:'Pa',n:'Протактиний',b:'f'},{z:92,s:'U',n:'Уран',b:'f'},{z:93,s:'Np',n:'Нептуний',b:'f'},{z:94,s:'Pu',n:'Плутоний',b:'f'},{z:95,s:'Am',n:'Америций',b:'f'},{z:96,s:'Cm',n:'Кюрий',b:'f'},{z:97,s:'Bk',n:'Берклий',b:'f'},{z:98,s:'Cf',n:'Калифорний',b:'f'},{z:99,s:'Es',n:'Эйнштейний',b:'f'},{z:100,s:'Fm',n:'Фермий',b:'f'},{z:101,s:'Md',n:'Менделевий',b:'f'},{z:102,s:'No',n:'Нобелий',b:'f'},{z:103,s:'Lr',n:'Лоуренсий',b:'f'},{z:104,s:'Rf',n:'Резерфордий',b:'d'},{z:105,s:'Db',n:'Дубний',b:'d'},{z:106,s:'Sg',n:'Сиборгий',b:'d'},{z:107,s:'Bh',n:'Борий',b:'d'},{z:108,s:'Hs',n:'Хассий',b:'d'},{z:109,s:'Mt',n:'Мейтнерий',b:'d'},{z:110,s:'Ds',n:'Дармштадтий',b:'d'},{z:111,s:'Rg',n:'Рентгений',b:'d'},{z:112,s:'Cn',n:'Коперниций',b:'d'},{z:113,s:'Nh',n:'Нихоний',b:'p'},{z:114,s:'Fl',n:'Флеровий',b:'p'},{z:115,s:'Mc',n:'Московий',b:'p'},{z:116,s:'Lv',n:'Ливерморий',b:'p'},{z:117,s:'Ts',n:'Теннессин',b:'p'},{z:118,s:'Og',n:'Оганесон',b:'p'}
];
const BY_SYMBOL=Object.fromEntries(ELEMENTS.map(e=>[e.s,e]));
const PERIODIC_LAYOUT=[
  ['H','','','','','','','','','','','','','','','','','He'],
  ['Li','Be','','','','','','','','','','','B','C','N','O','F','Ne'],
  ['Na','Mg','','','','','','','','','','','Al','Si','P','S','Cl','Ar'],
  ['K','Ca','Sc','Ti','V','Cr','Mn','Fe','Co','Ni','Cu','Zn','Ga','Ge','As','Se','Br','Kr'],
  ['Rb','Sr','Y','Zr','Nb','Mo','Tc','Ru','Rh','Pd','Ag','Cd','In','Sn','Sb','Te','I','Xe'],
  ['Cs','Ba','La–Lu','Hf','Ta','W','Re','Os','Ir','Pt','Au','Hg','Tl','Pb','Bi','Po','At','Rn'],
  ['Fr','Ra','Ac–Lr','Rf','Db','Sg','Bh','Hs','Mt','Ds','Rg','Cn','Nh','Fl','Mc','Lv','Ts','Og'],
  ['', '', 'La','Ce','Pr','Nd','Pm','Sm','Eu','Gd','Tb','Dy','Ho','Er','Tm','Yb','Lu',''],
  ['', '', 'Ac','Th','Pa','U','Np','Pu','Am','Cm','Bk','Cf','Es','Fm','Md','No','Lr','']
];
function scrollToResults(){
  const el=document.querySelector('.content') || document.querySelector('#results');
  if(el) el.scrollIntoView({behavior:'smooth', block:'start'});
}
async function loadElements(){
  let available=new Set();
  try{const data=await api('/api/elements');available=new Set((data.elements||[]).map(e=>e.symbol));}catch(e){}
  $('#elements').innerHTML=PERIODIC_LAYOUT.map((row,ri)=>row.map(sym=>{
    if(!sym)return '<div class="el-space"></div>';
    if(sym.includes('–'))return `<div class="el-series">${sym}</div>`;
    const e=BY_SYMBOL[sym];
    const disabled=available.size && !available.has(sym);
    return `<button class="el block-${e.b} ${state.element===e.s?'active':''} ${disabled?'no-data':''}" data-el="${e.s}" title="${esc(e.n)}"><i>${e.z}</i><span>${e.s}</span><small>${esc(e.n)}</small></button>`;
  }).join('')).join('');
  document.querySelectorAll('.el').forEach(b=>b.onclick=()=>{state.element=b.dataset.el;state.page=1;renderActive();loadReactions(true);loadElements();history.pushState(null,'','/element/'+state.element);});
}
function renderActive(){const a=$('#activeElement'); if(state.element){const e=BY_SYMBOL[state.element];a.textContent='Элемент: '+state.element+(e?' — '+e.n:'');a.classList.remove('hidden')}else a.classList.add('hidden')}
async function loadReactions(shouldScroll=false){
  const params=new URLSearchParams({page:state.page,page_size:state.pageSize});
  if(state.q)params.set('q',state.q);if(state.element)params.set('element',state.element);
  const data=await api('/api/reactions?'+params);state.total=data.total;
  $('#resultTitle').textContent='Результаты поиска';
  $('#pageInfo').textContent=` стр. ${data.page} / ${Math.max(1,Math.ceil(data.total/data.page_size))} `;
  $('#prev').disabled=state.page<=1;$('#next').disabled=state.page>=Math.ceil(data.total/data.page_size);
  $('#results').innerHTML=data.items.map(r=>{const noGo=(r.equation||'').includes('↛')||r.description==='реакция не идёт';return `<article class="card ${noGo?'no-reaction':''}"><div class="eq"><a href="/reaction/${r.slug}">${fmtFormula(r.equation)}</a></div>${noGo?'<div class="note bad">реакция не идёт</div>':''}${r.conditions?`<div class="cond">${esc(r.conditions)}</div>`:''}<div class="els">${r.elements.map(e=>`<span>${e}</span>`).join('')}</div></article>`}).join('')||'<div class="panel">Ничего не найдено. Попробуй другой запрос.</div>';
  if(shouldScroll) requestAnimationFrame(scrollToResults);
}
async function loadOne(slug){
  const r=await api('/api/reactions/'+slug);
  $('#resultTitle').textContent='Карточка уравнения';
  const noGo=(r.equation||'').includes('↛')||r.description==='реакция не идёт';
  $('#results').innerHTML=`<article class="card ${noGo?'no-reaction':''}"><div class="eq">${fmtFormula(r.equation)}</div>${noGo?'<div class="note bad">реакция не идёт</div>':''}${r.conditions?`<div class="cond">${esc(r.conditions)}</div>`:''}<div class="els">${r.elements.map(e=>`<span>${e}</span>`).join('')}</div></article>`;
}
function initFromPath(){const p=location.pathname;if(p.startsWith('/reaction/')) return loadOne(p.split('/').pop()); if(p.startsWith('/element/')) state.element=decodeURIComponent(p.split('/').pop());}
$('#searchBtn').onclick=()=>{state.q=$('#q').value.trim();state.page=1;loadReactions(true);};
$('#q').addEventListener('keydown',e=>{if(e.key==='Enter')$('#searchBtn').click();});
$('#clearFilters').onclick=()=>{state={q:'',element:'',page:1,pageSize:30,total:0};$('#q').value='';renderActive();history.pushState(null,'','/');loadElements();loadReactions();};
$('#prev').onclick=()=>{if(state.page>1){state.page--;loadReactions(true);}};
$('#next').onclick=()=>{if(state.page<Math.ceil(state.total/state.pageSize)){state.page++;loadReactions(true);}};
initFromPath();renderActive();loadElements();loadAd();if(!location.pathname.startsWith('/reaction/'))loadReactions();
