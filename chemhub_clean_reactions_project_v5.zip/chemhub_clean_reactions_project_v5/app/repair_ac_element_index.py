import json
import time
import server


def main():
    server.init_db()
    con = server.connect()
    cur = con.cursor()
    rows = cur.execute('SELECT id, equation, elements_json FROM reactions').fetchall()
    changed = 0
    ac_total = 0
    for row in rows:
        elements = server.extract_elements(row['equation'])
        if 'Ac' in elements:
            ac_total += 1
        encoded = json.dumps(elements, ensure_ascii=False)
        if encoded != (row['elements_json'] or '[]'):
            cur.execute('UPDATE reactions SET elements_json=?, updated_at=? WHERE id=?', (encoded, time.time(), row['id']))
            changed += 1
    con.commit()
    con.close()
    print(f'[OK] Element index repaired. Changed rows: {changed}. Rows with real Ac: {ac_total}.')

if __name__ == '__main__':
    main()
