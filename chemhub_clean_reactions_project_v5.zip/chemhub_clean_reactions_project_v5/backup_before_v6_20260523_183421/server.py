
import csv, json, os, re, sqlite3, time
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, unquote
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
DATA_DIR = APP_DIR / 'data'
PUBLIC_DIR = APP_DIR / 'public'
DB_PATH = DATA_DIR / 'chemhub.sqlite'
SEED_PATH = DATA_DIR / 'reactions_seed.json'
ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD', 'Ch3mHub!Admin#2026')

VALID_ELEMENTS = set('H He Li Be B C N O F Ne Na Mg Al Si P S Cl Ar K Ca Sc Ti V Cr Mn Fe Co Ni Cu Zn Ga Ge As Se Br Kr Rb Sr Y Zr Nb Mo Tc Ru Rh Pd Ag Cd In Sn Sb Te I Xe Cs Ba La Ce Pr Nd Pm Sm Eu Gd Tb Dy Ho Er Tm Yb Lu Hf Ta W Re Os Ir Pt Au Hg Tl Pb Bi Po At Rn Fr Ra Ac Th Pa U Np Pu Am Cm Bk Cf Es Fm Md No Lr Rf Db Sg Bh Hs Mt Ds Rg Cn Nh Fl Mc Lv Ts Og'.split())

ELEMENT_NAMES = {
    'H':'Водород','He':'Гелий','Li':'Литий','Be':'Бериллий','B':'Бор','C':'Углерод','N':'Азот','O':'Кислород','F':'Фтор','Ne':'Неон',
    'Na':'Натрий','Mg':'Магний','Al':'Алюминий','Si':'Кремний','P':'Фосфор','S':'Сера','Cl':'Хлор','Ar':'Аргон','K':'Калий','Ca':'Кальций',
    'Sc':'Скандий','Ti':'Титан','V':'Ванадий','Cr':'Хром','Mn':'Марганец','Fe':'Железо','Co':'Кобальт','Ni':'Никель','Cu':'Медь','Zn':'Цинк',
    'Ga':'Галлий','Ge':'Германий','As':'Мышьяк','Se':'Селен','Br':'Бром','Kr':'Криптон','Rb':'Рубидий','Sr':'Стронций','Y':'Иттрий','Zr':'Цирконий',
    'Nb':'Ниобий','Mo':'Молибден','Tc':'Технеций','Ru':'Рутений','Rh':'Родий','Pd':'Палладий','Ag':'Серебро','Cd':'Кадмий','In':'Индий','Sn':'Олово',
    'Sb':'Сурьма','Te':'Теллур','I':'Иод','Xe':'Ксенон','Cs':'Цезий','Ba':'Барий','La':'Лантан','Ce':'Церий','Pr':'Празеодим','Nd':'Неодим',
    'Pm':'Прометий','Sm':'Самарий','Eu':'Европий','Gd':'Гадолиний','Tb':'Тербий','Dy':'Диспрозий','Ho':'Гольмий','Er':'Эрбий','Tm':'Тулий','Yb':'Иттербий',
    'Lu':'Лютеций','Hf':'Гафний','Ta':'Тантал','W':'Вольфрам','Re':'Рений','Os':'Осмий','Ir':'Иридий','Pt':'Платина','Au':'Золото','Hg':'Ртуть',
    'Tl':'Таллий','Pb':'Свинец','Bi':'Висмут','Po':'Полоний','At':'Астат','Rn':'Радон','Fr':'Франций','Ra':'Радий','Ac':'Актиний','Th':'Торий',
    'Pa':'Протактиний','U':'Уран','Np':'Нептуний','Pu':'Плутоний','Am':'Америций','Cm':'Кюрий','Bk':'Берклий','Cf':'Калифорний','Es':'Эйнштейний','Fm':'Фермий',
    'Md':'Менделевий','No':'Нобелий','Lr':'Лоуренсий','Rf':'Резерфордий','Db':'Дубний','Sg':'Сиборгий','Bh':'Борий','Hs':'Хассий','Mt':'Мейтнерий','Ds':'Дармштадтий',
    'Rg':'Рентгений','Cn':'Коперниций','Nh':'Нихоний','Fl':'Флеровий','Mc':'Московий','Lv':'Ливерморий','Ts':'Теннессин','Og':'Оганесон'
}

PERIODIC_ORDER = 'H He Li Be B C N O F Ne Na Mg Al Si P S Cl Ar K Ca Sc Ti V Cr Mn Fe Co Ni Cu Zn Ga Ge As Se Br Kr Rb Sr Y Zr Nb Mo Tc Ru Rh Pd Ag Cd In Sn Sb Te I Xe Cs Ba La Ce Pr Nd Pm Sm Eu Gd Tb Dy Ho Er Tm Yb Lu Hf Ta W Re Os Ir Pt Au Hg Tl Pb Bi Po At Rn Fr Ra Ac Th Pa U Np Pu Am Cm Bk Cf Es Fm Md No Lr Rf Db Sg Bh Hs Mt Ds Rg Cn Nh Fl Mc Lv Ts Og'.split()


def connect():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def get_setting(key, default):
    con=connect(); cur=con.cursor()
    try:
        row=cur.execute('SELECT value FROM settings WHERE key=?',(key,)).fetchone()
        con.close()
        return json.loads(row['value']) if row else default
    except Exception:
        con.close(); return default

def set_setting(key, value):
    con=connect(); cur=con.cursor()
    cur.execute('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', (key, json.dumps(value,ensure_ascii=False)))
    con.commit(); con.close()

def default_ad():
    return {'enabled': False, 'title': 'Реклама', 'text': 'Здесь может быть ваша реклама', 'url': '', 'button': 'Подробнее'}

def split_equation(eq):
    eq = (eq or '').replace('⟶','->').replace('→','->').replace('=', '->').replace('⇄','<->').replace('↔','<->').replace('-/->','↛')
    if '↛' in eq:
        a,b = eq.split('↛',1); return a.strip(), b.strip(), '↛'
    if '<->' in eq:
        a,b = eq.split('<->',1); return a.strip(), b.strip(), '<->'
    if '->' in eq:
        a,b = eq.split('->',1); return a.strip(), b.strip(), '->'
    return eq.strip(), '', '->'

def clean_eq(eq):
    eq = (eq or '').strip().replace('→','->').replace('⟶','->').replace('=', '->').replace('⇄','<->').replace('↔','<->').replace('-/->','↛')
    return re.sub(r'\s+', ' ', eq)

def strip_coeff(term):
    term = term.strip()
    term = re.sub(r'^[0-9]+(?:[.,][0-9]+)?\s*', '', term)
    term = term.replace('↑','').replace('↓','')
    term = re.sub(r'\((aq|s|l|g|тв|ж|газ|р-р|конц\.?|разб\.?|\d+\s*%)[^)]*\)', '', term, flags=re.I)
    return re.sub(r'\s+', '', term)

def side_key(side):
    return '+'.join(sorted([strip_coeff(x) for x in side.split('+') if strip_coeff(x)]))

def normalized_key(eq):
    left,right,arrow=split_equation(eq)
    if arrow == '↛':
        return side_key(left)+'|NO_REACTION'
    return side_key(left)+'|'+side_key(right)

def extract_elements(eq):
    # Exact element logic: HF = H + F, Hf = Hf; Na never matches N.
    eq = clean_eq(eq).replace('->',' ').replace('<->',' ')
    found=[]
    for m in re.finditer(r'[A-Z][a-z]?', eq):
        s=m.group(0)
        if s in VALID_ELEMENTS:
            found.append(s)
    present=set(found)
    return [e for e in PERIODIC_ORDER if e in present]

def slugify(eq):
    left,_,_=split_equation(eq)
    base=re.sub(r'[^A-Za-zА-Яа-я0-9]+','-', left.lower()).strip('-')[:70]
    return base or str(abs(hash(eq)))

def init_db():
    DATA_DIR.mkdir(exist_ok=True)
    con=connect(); cur=con.cursor()
    cur.execute('''CREATE TABLE IF NOT EXISTS reactions(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        equation TEXT NOT NULL,
        reactants TEXT,
        products TEXT,
        conditions TEXT,
        description TEXT,
        source TEXT,
        source_page INTEGER,
        origin TEXT,
        slug TEXT UNIQUE,
        elements_json TEXT,
        normalized_key TEXT UNIQUE,
        approved INTEGER DEFAULT 1,
        hidden INTEGER DEFAULT 0,
        created_at REAL,
        updated_at REAL
    )''')
    cur.execute('CREATE INDEX IF NOT EXISTS idx_reactions_slug ON reactions(slug)')
    cur.execute('CREATE INDEX IF NOT EXISTS idx_reactions_norm ON reactions(normalized_key)')
    cur.execute('CREATE INDEX IF NOT EXISTS idx_reactions_origin ON reactions(origin)')
    cur.execute('CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL)')
    if not cur.execute('SELECT value FROM settings WHERE key=?', ('ad',)).fetchone():
        cur.execute('INSERT INTO settings(key,value) VALUES(?,?)', ('ad', json.dumps(default_ad(), ensure_ascii=False)))
    con.commit()
    count=cur.execute('SELECT COUNT(*) FROM reactions').fetchone()[0]
    if count==0 and SEED_PATH.exists():
        seed=json.loads(SEED_PATH.read_text(encoding='utf-8'))
        import_records(seed, replace=False, con=con)
    con.close()

def row_to_dict(r):
    d=dict(r)
    d['elements']=json.loads(d.pop('elements_json') or '[]')
    d['approved']=bool(d['approved']); d['hidden']=bool(d['hidden'])
    return d

def insert_or_merge(cur, item):
    eq=clean_eq(item.get('equation',''))
    if not eq or ('->' not in eq and '<->' not in eq and '↛' not in eq):
        return False, 'bad_equation'
    left,right,_=split_equation(eq)
    norm=item.get('normalized_key') or normalized_key(eq)
    elements=item.get('elements') or extract_elements(eq)
    slug=item.get('slug') or slugify(eq)
    # ensure unique slug
    existing=cur.execute('SELECT id, conditions, description, source, origin FROM reactions WHERE normalized_key=?', (norm,)).fetchone()
    now=time.time()
    if existing:
        old=dict(existing)
        conditions=old.get('conditions') or ''
        if item.get('conditions') and item['conditions'] not in conditions:
            conditions=(conditions+'; '+item['conditions']).strip('; ')
        source=old.get('source') or ''
        if item.get('source') and item['source'] not in source:
            source=(source+'; '+item['source']).strip('; ')
        origin=old.get('origin') or ''
        if item.get('origin') and item['origin'] not in origin:
            origin=(origin+'; '+item['origin']).strip('; ')
        description=old.get('description') or item.get('description','') or ''
        cur.execute('''UPDATE reactions SET conditions=?, description=?, source=?, origin=?, elements_json=?, updated_at=? WHERE id=?''',
                    (conditions, description, source, origin, json.dumps(elements,ensure_ascii=False), now, old['id']))
        return True, 'merged'
    base=slug; n=2
    while cur.execute('SELECT id FROM reactions WHERE slug=?',(slug,)).fetchone():
        slug=f'{base}-{n}'; n+=1
    cur.execute('''INSERT INTO reactions(equation,reactants,products,conditions,description,source,source_page,origin,slug,elements_json,normalized_key,approved,hidden,created_at,updated_at)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
        (eq, item.get('reactants') or left, item.get('products') or right, item.get('conditions',''), item.get('description',''), item.get('source',''), item.get('source_page'), item.get('origin','manual'), slug, json.dumps(elements,ensure_ascii=False), norm, int(item.get('approved',True)), int(item.get('hidden',False)), now, now))
    return True, 'inserted'

def import_records(records, replace=False, con=None):
    own=False
    if con is None:
        con=connect(); own=True
    cur=con.cursor()
    if replace:
        cur.execute('DELETE FROM reactions')
    stats={'inserted':0,'merged':0,'bad_equation':0}
    for item in records:
        ok,status=insert_or_merge(cur,item)
        stats[status]=stats.get(status,0)+1
    con.commit()
    if own: con.close()
    return stats

def read_body(handler):
    n=int(handler.headers.get('Content-Length','0') or 0)
    return handler.rfile.read(n) if n else b''

def is_admin(handler):
    return handler.headers.get('X-Admin-Password') == ADMIN_PASSWORD

class Handler(BaseHTTPRequestHandler):
    server_version = 'ChemHubClean/1.0'
    def log_message(self, fmt, *args):
        return
    def send_json(self, data, status=200):
        b=json.dumps(data, ensure_ascii=False, indent=2).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Access-Control-Allow-Origin','*')
        self.send_header('Access-Control-Allow-Headers','Content-Type, X-Admin-Password')
        self.send_header('Access-Control-Allow-Methods','GET,POST,PUT,DELETE,OPTIONS')
        self.send_header('Content-Length',str(len(b)))
        self.end_headers(); self.wfile.write(b)
    def send_text(self, text, content_type='text/plain; charset=utf-8', status=200):
        b=text.encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Access-Control-Allow-Origin','*')
        self.send_header('Content-Length',str(len(b)))
        self.end_headers(); self.wfile.write(b)
    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header('Access-Control-Allow-Origin','*')
        self.send_header('Access-Control-Allow-Headers','Content-Type, X-Admin-Password')
        self.send_header('Access-Control-Allow-Methods','GET,POST,PUT,DELETE,OPTIONS')
        self.end_headers()
    def do_GET(self):
        p=urlparse(self.path); path=unquote(p.path); qs=parse_qs(p.query)
        try:
            if path == '/api/stats': return self.api_stats()
            if path == '/api/elements': return self.api_elements()
            if path == '/api/sources': return self.api_sources()
            if path == '/api/ad': return self.api_ad()
            if path == '/api/reactions': return self.api_reactions(qs)
            if path.startswith('/api/reactions/'):
                return self.api_reaction_slug(path.split('/')[-1])
            if path == '/api/export/json': return self.export_json()
            if path == '/api/export/csv': return self.export_csv()
            if path == '/api/health': return self.send_json({'ok':True})
            if path == '/admin' or path == '/admin/': return self.serve_file('admin.html')
            if path == '/' or path.startswith('/reaction/') or path.startswith('/element/') or path == '/seo/reactions': return self.serve_file('index.html')
            if path.startswith('/static/'):
                return self.serve_file(path.replace('/static/',''))
            # direct files
            name=path.lstrip('/')
            if name in {'styles.css','app.js','admin.js'}: return self.serve_file(name)
            self.send_json({'error':'not_found'},404)
        except Exception as e:
            self.send_json({'error':str(e)},500)
    def do_POST(self):
        p=urlparse(self.path); path=unquote(p.path); qs=parse_qs(p.query)
        if path == '/api/admin/login':
            data=json.loads(read_body(self) or b'{}')
            return self.send_json({'ok': data.get('password') == ADMIN_PASSWORD})
        if not is_admin(self): return self.send_json({'error':'admin_password_required'},401)
        try:
            if path == '/api/admin/ad':
                data=json.loads(read_body(self) or b'{}')
                ad={
                    'enabled': bool(data.get('enabled')),
                    'title': str(data.get('title','Реклама'))[:80],
                    'text': str(data.get('text',''))[:300],
                    'url': str(data.get('url',''))[:400],
                    'button': str(data.get('button','Подробнее'))[:40],
                }
                set_setting('ad', ad)
                return self.send_json({'ok':True,'ad':ad})
            if path == '/api/admin/reactions':
                item=json.loads(read_body(self) or b'{}')
                stats=import_records([item])
                return self.send_json({'ok':True,'stats':stats})
            if path == '/api/admin/import':
                data=json.loads(read_body(self) or b'[]')
                if isinstance(data, dict): data=data.get('reactions',[])
                stats=import_records(data, replace=qs.get('replace',['0'])[0]=='1')
                return self.send_json({'ok':True,'stats':stats})
            if path == '/api/admin/reseed':
                data=json.loads(SEED_PATH.read_text(encoding='utf-8'))
                stats=import_records(data, replace=True)
                return self.send_json({'ok':True,'stats':stats})
            self.send_json({'error':'not_found'},404)
        except Exception as e:
            self.send_json({'error':str(e)},500)
    def do_PUT(self):
        p=urlparse(self.path); path=unquote(p.path)
        if not is_admin(self): return self.send_json({'error':'admin_password_required'},401)
        if not path.startswith('/api/admin/reactions/'): return self.send_json({'error':'not_found'},404)
        rid=path.split('/')[-1]
        item=json.loads(read_body(self) or b'{}')
        con=connect(); cur=con.cursor()
        eq=clean_eq(item.get('equation',''))
        left,right,_=split_equation(eq)
        elements=extract_elements(eq)
        norm=normalized_key(eq)
        cur.execute('''UPDATE reactions SET equation=?, reactants=?, products=?, conditions=?, description=?, source=?, source_page=?, origin=?, elements_json=?, normalized_key=?, approved=?, hidden=?, updated_at=? WHERE id=?''',
            (eq,item.get('reactants') or left,item.get('products') or right,item.get('conditions',''),item.get('description',''),item.get('source','manual'),item.get('source_page'),item.get('origin','manual'),json.dumps(elements,ensure_ascii=False),norm,int(item.get('approved',True)),int(item.get('hidden',False)),time.time(),rid))
        con.commit(); con.close(); self.send_json({'ok':True})
    def do_DELETE(self):
        p=urlparse(self.path); path=unquote(p.path)
        if not is_admin(self): return self.send_json({'error':'admin_password_required'},401)
        if not path.startswith('/api/admin/reactions/'): return self.send_json({'error':'not_found'},404)
        rid=path.split('/')[-1]
        con=connect(); con.execute('DELETE FROM reactions WHERE id=?',(rid,)); con.commit(); con.close(); self.send_json({'ok':True})
    def serve_file(self, name):
        file=(PUBLIC_DIR/name).resolve()
        if not str(file).startswith(str(PUBLIC_DIR.resolve())) or not file.exists():
            return self.send_json({'error':'file_not_found'},404)
        ct='text/html; charset=utf-8'
        if file.suffix=='.css': ct='text/css; charset=utf-8'
        if file.suffix=='.js': ct='application/javascript; charset=utf-8'
        self.send_text(file.read_text(encoding='utf-8'), ct)
    def api_stats(self):
        con=connect(); cur=con.cursor()
        total=cur.execute('SELECT COUNT(*) FROM reactions WHERE hidden=0').fetchone()[0]
        pdf=cur.execute("SELECT COUNT(*) FROM reactions WHERE hidden=0 AND origin LIKE '%pdf_mescheryakov_starykh%'").fetchone()[0]
        olymp=cur.execute("SELECT COUNT(*) FROM reactions WHERE hidden=0 AND origin LIKE '%olympiad%'").fetchone()[0]
        cond=cur.execute("SELECT COUNT(*) FROM reactions WHERE hidden=0 AND TRIM(COALESCE(conditions,''))<>''").fetchone()[0]
        con.close(); self.send_json({'total':total,'pdf_mescheryakov_starykh':pdf,'olympiad_common':olymp,'with_conditions':cond,'no_ai_agent':True})
    def api_elements(self):
        con=connect(); rows=con.execute('SELECT elements_json FROM reactions WHERE hidden=0').fetchall(); con.close()
        counts={e:0 for e in PERIODIC_ORDER}
        for r in rows:
            for e in json.loads(r['elements_json'] or '[]'):
                counts[e]=counts.get(e,0)+1
        data=[{'symbol':e,'name':ELEMENT_NAMES.get(e,e),'count':counts[e]} for e in PERIODIC_ORDER if counts.get(e,0)>0]
        self.send_json({'elements':data})
    def api_ad(self):
        self.send_json(get_setting('ad', default_ad()))

    def api_sources(self):
        con=connect(); rows=con.execute('SELECT source, COUNT(*) c FROM reactions WHERE hidden=0 GROUP BY source ORDER BY c DESC, source').fetchall(); con.close()
        self.send_json({'sources':[dict(r) for r in rows]})
    def api_reactions(self, qs):
        q=(qs.get('q',[''])[0] or '').strip()
        element=(qs.get('element',[''])[0] or '').strip()
        source=(qs.get('source',[''])[0] or '').strip()
        page=max(1,int(qs.get('page',['1'])[0] or 1)); page_size=min(200,max(1,int(qs.get('page_size',['30'])[0] or 30)))
        where=['hidden=0']; args=[]
        if q:
            like=f'%{q}%'; where.append('(equation LIKE ? OR reactants LIKE ? OR products LIKE ? OR conditions LIKE ? OR description LIKE ? OR source LIKE ?)'); args += [like]*6
        if element:
            if element not in VALID_ELEMENTS: return self.send_json({'items':[],'total':0,'page':page,'page_size':page_size,'exact_element_logic':True})
            where.append('elements_json LIKE ?'); args.append(f'%"{element}"%')
        if source:
            where.append('source LIKE ?'); args.append(f'%{source}%')
        sqlw=' AND '.join(where)
        con=connect(); cur=con.cursor()
        total=cur.execute(f'SELECT COUNT(*) FROM reactions WHERE {sqlw}', args).fetchone()[0]
        rows=cur.execute(f'SELECT * FROM reactions WHERE {sqlw} ORDER BY id LIMIT ? OFFSET ?', args+[page_size,(page-1)*page_size]).fetchall()
        con.close(); self.send_json({'items':[row_to_dict(r) for r in rows], 'total':total, 'page':page, 'page_size':page_size, 'exact_element_logic':True})
    def api_reaction_slug(self, slug):
        con=connect(); row=con.execute('SELECT * FROM reactions WHERE slug=? AND hidden=0',(slug,)).fetchone(); con.close()
        if not row: return self.send_json({'error':'not_found'},404)
        self.send_json(row_to_dict(row))
    def export_json(self):
        con=connect(); rows=con.execute('SELECT * FROM reactions WHERE hidden=0 ORDER BY id').fetchall(); con.close()
        self.send_json([row_to_dict(r) for r in rows])
    def export_csv(self):
        con=connect(); rows=[row_to_dict(r) for r in con.execute('SELECT * FROM reactions WHERE hidden=0 ORDER BY id').fetchall()]; con.close()
        fields=['id','equation','reactants','products','conditions','description','source','source_page','origin','slug','elements']
        import io
        s=io.StringIO(); w=csv.DictWriter(s,fieldnames=fields); w.writeheader()
        for r in rows:
            row={k:r.get(k,'') for k in fields}; row['elements']=' '.join(r.get('elements',[])); w.writerow(row)
        self.send_text(s.getvalue(),'text/csv; charset=utf-8')

if __name__ == '__main__':
    init_db()
    host='0.0.0.0'; port=int(os.environ.get('PORT','8000'))
    print(f'ChemHub Clean server on http://{host}:{port}')
    ThreadingHTTPServer((host, port), Handler).serve_forever()
