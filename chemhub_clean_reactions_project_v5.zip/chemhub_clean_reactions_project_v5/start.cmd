@echo off
cd /d %~dp0
docker compose up -d
start http://localhost:3000
start http://localhost:3100/admin
