param(
  [string]$ProjectRoot = "C:\chemhub_clean_reactions_project_v5"
)

$ErrorActionPreference = "Stop"
Write-Host "[ChemHub Clean v6] Project root: $ProjectRoot"
$PatchRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
if (!(Test-Path $ProjectRoot)) { throw "Project root not found: $ProjectRoot" }
if (!(Test-Path (Join-Path $ProjectRoot "docker-compose.yml"))) { throw "docker-compose.yml not found in $ProjectRoot" }

$backup = Join-Path $ProjectRoot ("backup_before_v6_" + (Get-Date -Format "yyyyMMdd_HHmmss"))
New-Item -ItemType Directory -Force $backup | Out-Null
Copy-Item (Join-Path $ProjectRoot "app\server.py") (Join-Path $backup "server.py") -Force
if (Test-Path (Join-Path $ProjectRoot "app\data\reactions_seed.json")) { Copy-Item (Join-Path $ProjectRoot "app\data\reactions_seed.json") (Join-Path $backup "reactions_seed.json") -Force }
if (Test-Path (Join-Path $ProjectRoot "app\data\reactions_seed.csv")) { Copy-Item (Join-Path $ProjectRoot "app\data\reactions_seed.csv") (Join-Path $backup "reactions_seed.csv") -Force }
Write-Host "[OK] Backup created: $backup"

Copy-Item (Join-Path $PatchRoot "app\server.py") (Join-Path $ProjectRoot "app\server.py") -Force
Copy-Item (Join-Path $PatchRoot "app\repair_ac_element_index.py") (Join-Path $ProjectRoot "app\repair_ac_element_index.py") -Force
Copy-Item (Join-Path $PatchRoot "app\data\reactions_seed.json") (Join-Path $ProjectRoot "app\data\reactions_seed.json") -Force
Copy-Item (Join-Path $PatchRoot "app\data\reactions_seed.csv") (Join-Path $ProjectRoot "app\data\reactions_seed.csv") -Force
Write-Host "[OK] Files copied"

Push-Location $ProjectRoot
try {
  docker compose up -d
  Write-Host "[ChemHub Clean v6] Recalculating element index in current SQLite DB..."
  docker compose exec -T chemhub python /app/repair_ac_element_index.py
  docker compose restart chemhub
  Write-Host "[OK] v6 applied. Check: http://localhost:3000/element/Ac"
} finally {
  Pop-Location
}
